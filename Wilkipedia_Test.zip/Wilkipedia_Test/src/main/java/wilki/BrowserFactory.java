package wilki;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Created by smita on 07/05/2016.
 */
public abstract class BrowserFactory {
    public static WebDriver driver;

    public static WebDriver StartBrowser(String Browser){
        if (Browser.equalsIgnoreCase("Firefox")) {
            driver = new FirefoxDriver();
        }
        return driver;
    }

    public static WebDriver getDriver()
    {
        return driver;
    }

}