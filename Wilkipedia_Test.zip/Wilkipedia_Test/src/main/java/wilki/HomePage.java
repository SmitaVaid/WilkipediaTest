package wilki;

import junit.framework.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by smita on 07/05/2016.
 */
public class HomePage {
    //WebDriver driver = BrowserFactory.driver;
    WebDriver driver = BrowserFactory.getDriver();

    public void SearchItem(String searchItem) {
        driver.findElement(By.id("searchInput")).sendKeys(searchItem);
        //driver.findElement(By.id("search-input")).click(); go
       // driver.findElement(By.xpath("html/body/div[2]/form/fieldset/button")).click();
    }

    public void NavigateToSearchResultPage() {
        driver.findElement(By.xpath("html/body/div[2]/form/fieldset/button")).click();
        Assert.assertTrue("Search results", true);

    }
}
