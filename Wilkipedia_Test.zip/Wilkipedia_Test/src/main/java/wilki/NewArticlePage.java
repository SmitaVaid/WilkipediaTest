package wilki;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by smita on 07/05/2016.
 */
public class NewArticlePage {
    WebDriver driver = BrowserFactory.getDriver();

    public void VerifyTitleAndTableContent() {
        driver.findElements(By.id("firstHeading"));
       Assert.assertTrue(Utils.isTextPresent("List of fictional rabbits and hares"));
        driver.findElements(By.xpath("html/body/div[3]/div[3]/div[4]/div[2]/div/h2"));
        Assert.assertTrue(Utils.isTextPresent("Contents"));
    }
}
