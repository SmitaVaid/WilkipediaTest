package wilki;

import junit.framework.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by smita on 07/05/2016.
 */
public class SearchResultPage {
    WebDriver driver = BrowserFactory.getDriver();

    public void CheckSuggestion() {
        driver.findElement(By.id("mw-search-DYM-suggestion")).click();
        Utils.sleep(5);
    }

    public void VerifySearchResult() {
        driver.findElements(By.linkText("next 20"));
    }

    public void ClickFirstSearchResult() {
        driver.findElement(By.linkText("List of fictional rabbits and hares")).click();

    }

    public void NavigateToNewArticlePage() {
        driver.findElements(By.id("firstHeading"));
        Assert.assertTrue("List of fictional rabbits and hares", true);
    }
}
