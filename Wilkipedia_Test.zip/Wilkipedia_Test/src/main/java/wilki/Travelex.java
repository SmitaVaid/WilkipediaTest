package wilki;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by smita on 07/05/2016.
 */
public class Travelex {
    WebDriver driver = BrowserFactory.getDriver();

    public void VerifySlider() {
        driver.findElement(By.xpath("//div[1]/ul/li[1]/button"));
    }

    public void MoveToSecondLeftSlider() {
        driver.findElement(By.xpath("//div[1]/ul/li[2]/button")).click();

    }
    public void MoveToThirdLeftSlider() {
        driver.findElement(By.xpath("//div[1]/ul/li[3]/button")).click();

    }
}
