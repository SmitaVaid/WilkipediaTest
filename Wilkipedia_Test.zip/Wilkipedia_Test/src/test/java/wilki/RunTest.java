package wilki;

/**
 * Created by smita on 12/03/2016.
 */
import org.junit.runner.RunWith;

import cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@Cucumber.Options(
        format = {"html:target/cucumber"},
        tags = "@travelex")
public class RunTest {
}
