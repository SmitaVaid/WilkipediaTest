package wilki;

/**
 * Created by smita on 12/03/2016.
 */

import cucumber.annotation.After;
import cucumber.annotation.Before;
import cucumber.annotation.en.And;
import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
import org.junit.Assert;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;

import java.net.MalformedURLException;

public class StepDefs {
    static WebDriver driver;
    HomePage home;
    SearchResultPage search;
    NewArticlePage newArticle;
    Travelex travel;

    @Before
   public void StartBrowser() throws MalformedURLException, InterruptedException {
      try {
          BrowserFactory.StartBrowser("firefox");
          driver = BrowserFactory.driver;
      } catch (Exception e) {
          e.printStackTrace();
      }

        home = new HomePage();
        search = new SearchResultPage();
        newArticle = new NewArticlePage();
        travel = new Travelex();
  }

    @Given("^User is on wilkipedia home page$")
    public void User_is_on_wilkipedia_home_page() {
       driver.get("https://www.wikipedia.org/");
       driver.manage().window().maximize();
       Assert.assertTrue("WikipediA", true);

    }

    @Then("^user can see page title as wilkipedia$")
    public void user_can_see_page_title_as_wilkipedia() {
       Assert.assertTrue("WikipediA", true);
        //Assert.assertTrue(Utils.isTextPresent("WikipediA"));
    }
    @When("^search result for \"([^\"]*)\"$")
    public void search_result_for(String arg1) {
        home.SearchItem("furry rabbits");
    }
    @Then("^user should navigate to search result page$")
    public void user_should_navigate_to_search_result_page() {
       home.NavigateToSearchResultPage();
    }

    @And("^user should get result as Did you mean: fury rabbit$")
    public void user_should_get_result_as_Did_you_mean_fury_rabbit() {
        Assert.assertTrue("Did you mean: fury rabbit", true);
        Utils.sleep(5);
    }

    @When("^click on the suggestion$")
    public void click_on_the_suggestion() {
        search.CheckSuggestion();
    }

    @Then("^user can see (\\d+) search results on page$")
    public void user_can_see_search_results_on_page(int arg1) {
       search.VerifySearchResult();

    }
    @When("^click on the first search result$")
    public void click_on_the_first_search_result() {
        search.ClickFirstSearchResult();

    }

    @Then("^user should navigate to new article page$")
    public void user_should_navigate_to_new_article_page() {
        search.NavigateToNewArticlePage();

    }

    @Then("^user should able to see title and table of contents for page$")
    public void user_should_able_to_see_title_and_table_of_contents_for_page() {
        newArticle.VerifyTitleAndTableContent();

    }


    @Given("^User is on travelex home page$")
    public void User_is_on_travelex_home_page() {
        driver.get("https://www.travelex.co.uk/");
    }

    @When("^he resize the window as (\\d+)px$")
    public void he_resize_the_window_as_px(int arg1) {
        driver.manage().window().maximize();
        Dimension d = new Dimension(550,550);
        //Resize the current window to the given dimension
        driver.manage().window().setSize(d);
        //System.out.println(driver.manage().window().getSize());
    }

    @Then("^window becomes a slider$")
    public void window_becomes_a_slider() {
        travel.VerifySlider();
    }

    @When("^swipe left to the second slider$")
    public void swipe_left_to_the_slider() {
       // driver.findElement(By.xpath("html/body/div[1]/div[3]/div/section[2]/article/div[1]/ul/li[2]/button")).click();
      travel.MoveToSecondLeftSlider();
    }

    @When("^swipe left to the third slider again$")
    public void swipe_left_to_the_slider_again() {
        travel.MoveToThirdLeftSlider();
    }

    @Then("^Third item should displayed as page title 'Explore our travel hub'$")
    public void Third_item_should_displayed_as_page_title_Explore_our_travel_hub() {
        Assert.assertTrue(Utils.isTextPresent("Explore our travel hub"));
    }

    @After
       public void stop()
      {
       driver.quit();

      }

}
